/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AStaterGuest;

import AStater.*;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class LoGicAL {

  static {
    int ask;
    do{
        String a,b,c,d,e;
        int a1=0,b1=0,c1=0,d1=0,e1=0;
    a=JOptionPane.showInputDialog(null,"ENTER THE VALUE 1 ");
    b=JOptionPane.showInputDialog(null,"ENTER THE VALUE 2 ");
    c=JOptionPane.showInputDialog(null,"ENTER THE VALUE 3 ");
    d=JOptionPane.showInputDialog(null,"ENTER THE VALUE 4 ");
    e=JOptionPane.showInputDialog(null,"ENTER THE VALUE 5 ");
    
    if(a.length()==0){
            a1=0;
        }    
    else{
            a1=Integer.parseInt(a);    
        }    
    if(b.length()==0){ 
            b1=0;
        }    
    else{
            b1=Integer.parseInt(b);    
        }    
    if(c.length()==0){
            c1=0;
        }    
    else{
            c1=Integer.parseInt(c);    
        }    
    if(d.length()==0){ 
            d1=0;
        }    
    else{
            d1=Integer.parseInt(d);    
        }    
    if(e.length()==0){ 
            e1=0;
        }
    else{
            e1=Integer.parseInt(e);    
        }
    int result =a1>b1?(a1>c1?(a1>d1?(a1>e1?a1:e1):d1):c1>d1?(c1>e1?c1:e1):(d1>e1?d1:e1)):(b1>c1?(b1>d1?b1:d1):c1>d1?(c1>e1?c1:e1):(d1>e1?d1:e1));
    JOptionPane.showMessageDialog(null,result);
        ask=JOptionPane.showConfirmDialog(null, "would you like capare another one");
    }while(ask==0);
    }
    
    
    
   public static void main(String args[]) {
      {
            new LoGicAL().setVisible(true);
        }
    }    

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
